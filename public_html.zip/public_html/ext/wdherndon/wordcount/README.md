# Word Count

## Installation

Copy the extension to phpBB/ext/wdherndon/wordcount

Go to "ACP" > "Customise" > "Extensions" and enable the "Word Count" extension.

## Tests and Continuous Integration

Currently only basic verification and "hand verification" of results.

## License

[GPLv2](license.txt)
